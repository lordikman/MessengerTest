//
//  SigninVC.swift
//  iSeekU
//
//  Created by Евгений on 16.01.2018.
//  Copyright © 2018 Lordikman. All rights reserved.
//

import UIKit
import FirebaseAuth

class SigninVC: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var WelcomeScreen: UIImageView!
    @IBOutlet weak var Start: UIButton!
    
    private let CONTACTS_SEGUE = "ContactsSegue";
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBAction func Startbuttompress(_ sender: Any) {
        Start.isHidden = true;
        WelcomeScreen.isHidden = true;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        }
    override func viewDidAppear(_ animated: Bool) {
        if AuthProvider.Instance.isLoggedIn(){
            performSegue(withIdentifier: self.CONTACTS_SEGUE, sender: nil)
        }
    }
    
    @IBAction func login(_ sender: Any) {
        emailTextfield.resignFirstResponder()
        passwordTextfield.resignFirstResponder()
        if emailTextfield.text != "" && passwordTextfield.text != ""{
            AuthProvider.Instance.login(withEmail: emailTextfield.text!, password: passwordTextfield.text!, loginHandler: {(message) in
                if message != nil{
                    self.alertTheUser(title: "Problems With Logging", message: message!)
                    self.emailTextfield.text = "";
                    self.passwordTextfield.text = "";
                } else {
                    self.emailTextfield.text = "";
                    self.passwordTextfield.text = "";
                    self.performSegue(withIdentifier: self.CONTACTS_SEGUE, sender: nil)
                }
            })
        } else {
            alertTheUser(title: "Email and Password are Required", message: "Please enter Email or Password");
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        emailTextfield.resignFirstResponder()
        passwordTextfield.resignFirstResponder()
        
    }
    @IBAction func signUp(_ sender: Any) {
        emailTextfield.resignFirstResponder()
        passwordTextfield.resignFirstResponder()
        if emailTextfield.text != "" && passwordTextfield.text != ""{
            AuthProvider.Instance.signUp(withEmail: emailTextfield.text!, password: passwordTextfield.text!, loginHandler: {(message) in
                if message != nil{
                    self.alertTheUser(title: "Problems With Creating new User", message: message!)
                    self.emailTextfield.text = "";
                    self.passwordTextfield.text = "";
                    
                }else{
                    self.performSegue(withIdentifier: self.CONTACTS_SEGUE, sender: nil)
                }
            })
            
        } else{
            
            alertTheUser(title: "Email and Password are Required", message: "Please enter Email or Password");
            
        }
       
    }
    
    private func alertTheUser(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(ok);
        present(alert,animated: true, completion: nil);
    }

    
}//class

