//
//  Constants.swift
//  iSeekU
//
//  Created by Евгений on 18.01.2018.
//  Copyright © 2018 Lordikman. All rights reserved.
//

import Foundation

class Constants {
    static let CONTACTS = "Contacts"
    static let MESSAGES = "Messages"
    static let MEDIA_MESSAGES = "Media_Messages"
    static let IMAGE_STORAGE = "Image_Storage"
    static let VIDEO_STORAGE = "Video_Storage"
    
    static let EMAIL = "email"
    static let PASSWORD = "password"
    static let DATA = "data"
    
    static let TEXT = "text"
    static let SENDER_ID = "sender_id"
    static let SENDER_NAME = "sender_name"
    static let URL = "url"
}//class
