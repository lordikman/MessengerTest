//
//  Contact.swift
//  iSeekU
//
//  Created by Евгений on 18.01.2018.
//  Copyright © 2018 Lordikman. All rights reserved.
//

import Foundation


class Contact{
    private var _name = ""
    private var _id = ""
    
    init(id: String, name: String) {
        _id = id;
        _name = name;
    }
    
    var name: String{
        return _name
    }
    
    var id: String{
        return _id
    }
}
